WARNING

if someone asks for a QR Code verification, just walk away!!!

Poland has a system of electronical IDs, you can mostly use them to buy stuff like alcohol or vapes. It is called mObywatel 2.0

You can only use the electronical app when for example going to the town office etc.

I am selling an exact replica of this app made in html + css

I have used this app to buy vapes and alcohol for a couple of months, and no one seems to care/notice.

DM Me for help if needed

Polish:

Tak w dużym skrócie sprzedaje podróbkę mObywatela 2.0. Kup a zobaczysz

How to use it (after buying)

1. Buy a cheap webhosting.
2. Upload the files there
3. Visit the site, and log-in using the cridentials:
Username: admin
AuthKey: admin
U need to change those, they are stored in an array in the file login.php
4. After you log in, click the generator and fill in the options. (Name, Surname, Date Of Birth, Pesel, Photo)
5. After that you will be brought to a site like yoursite.com/demobywatel_folder <ble ble ble>
6. That link, open in your phone and ADD THAT LINK AS A SHORT CUT TO THE MAIN SCREEN
For iPhone use safari as browser
For android use Kiwi Browser

Done
## Authors

- [@Saze](https://www.github.com/Sejzik)


## Support

For support, email me@saze.lol or join our Slack channel.

